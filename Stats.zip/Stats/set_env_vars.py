import os
def set_vars():
	os.environ['EMAIL_ADDRESS'] = "milosvuk999@gmail.com"
	os.environ['EMAIL_PASSWORD'] = "lightfintech"